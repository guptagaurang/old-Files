package com.challenger.jokes_challenger_api_clean_archichecture.utils


const val JOKES_DEFAULT_NUMBER = 20

const val EXPLICIT_KEYWORD = "explicit"