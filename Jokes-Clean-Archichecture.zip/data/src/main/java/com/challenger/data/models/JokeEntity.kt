package com.challenger.data.models


data class JokeEntity(val id:Int, val joke:String,val categories:List<String> ) {
}