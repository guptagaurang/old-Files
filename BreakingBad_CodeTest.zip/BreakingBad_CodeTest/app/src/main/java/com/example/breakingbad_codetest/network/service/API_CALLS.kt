package com.example.breakingbad_codetest.network.service

object API_CALLS {
    const val API_BASE_URL = "https://breakingbadapi.com/"
    const val API_CHARACTERLIST = "api/characters"
}
