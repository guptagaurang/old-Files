package com.challenger.remote.utils

const val BASE_URL = "http://api.icndb.com"
const val PATH_JOKE = "number"
const val PATH_EXCLUDE = "exclude"
const val GET_RANDOM_JOKES = "$BASE_URL/jokes/random/{$PATH_JOKE}"






