package com.challenger.domain.usercases.suite


import com.challenger.domain.usercases.GetJokeTest

import org.junit.runner.RunWith
import org.junit.runners.Suite

@RunWith(Suite::class)
@Suite.SuiteClasses(

    GetJokeTest::class


)
class JokeSuite