package com.challenger.remote.suite


import com.challenger.remote.GetJokesRemoteImplTest
import org.junit.runner.RunWith
import org.junit.runners.Suite

@RunWith(Suite::class)
@Suite.SuiteClasses(
    GetJokesRemoteImplTest::class
)
class GetJokesSuite