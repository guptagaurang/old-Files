package com.challenger.domain.models

data class Joke(val id:Int, val joke:String,val categories:List<String> )
