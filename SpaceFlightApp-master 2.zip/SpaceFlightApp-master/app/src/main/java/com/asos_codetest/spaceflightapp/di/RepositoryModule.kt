package com.asos_codetest.spaceflightapp.di

import com.asos_codetest.spaceflightapp.model.db.FlightDao
import com.asos_codetest.spaceflightapp.model.network.FlightApiService
import com.asos_codetest.spaceflightapp.repository.FlightRepository
import org.koin.dsl.module

val repoModule = module {
    fun provideRepository(dao: FlightDao,apiService: FlightApiService) : FlightRepository {
        return FlightRepository(dao, apiService)
    }

    single { provideRepository(get(), get()) }
}